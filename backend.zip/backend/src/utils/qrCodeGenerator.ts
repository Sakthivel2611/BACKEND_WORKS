import QRCode from 'qrcode';

export const generateQRCode = async (upiId: string) => {
  const qrCode = await QRCode.toDataURL(`upi://pay?pa=${upiId}`);
  return qrCode;
};