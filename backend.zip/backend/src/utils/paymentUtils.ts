export const validatePaymentMethod = (method: string, customNote?: string) => {
    if (method === 'other' && !customNote) {
      throw new Error('Custom note is required for "other" payment method');
    }
  };