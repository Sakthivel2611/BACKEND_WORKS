import { Request, Response } from 'express';
import Order from '../models/Order';

export const getSalesReport = async (req: Request, res: Response) => {
  try {
    const { startDate, endDate } = req.query;

    const orders = await Order.find({
      createdAt: { $gte: new Date(startDate as string), $lte: new Date(endDate as string) },
    });

    const totalSales = orders.reduce((sum, order) => sum + order.total, 0);

    res.json({ totalSales, orders });
  } catch (error) {
    res.status(500).json({ message: 'Failed to generate sales report' });
  }
};