import { Request, Response } from 'express';
import Trophy from '../models/Trophy';

export const getTrophies = async (req: Request, res: Response) => {
  try {
    const trophies = await Trophy.find();
    res.json(trophies);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch trophies' });
  }
};

export const createTrophy = async (req: Request, res: Response) => {
  try {
    const { name, price, stock } = req.body;
    const trophy = new Trophy({ name, price, stock });
    await trophy.save();
    res.status(201).json(trophy);
  } catch (error) {
    res.status(400).json({ message: 'Failed to create trophy' });
  }
};