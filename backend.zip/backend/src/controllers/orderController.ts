import { Request, Response } from 'express';
import Order from '../models/Order';

export const createOrder = async (req: Request, res: Response) => {
  try {
    const { customerName, items, total, paymentMethod, customNote } = req.body;

    const order = new Order({
      customerName,
      items,
      total,
      paymentMethod,
      customNote,
    });

    await order.save();
    res.status(201).json(order);
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ message: 'Failed to create order' });
  }
};
export const getOrders = async (req: Request, res: Response) => {
  try {
    const orders = await Order.find().populate('items.trophy');
    res.status(200).json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ message: 'Failed to fetch orders' });
  }
};