import express from 'express';
import dotenv from 'dotenv';
import connectDB from './config/db';
import trophyRoutes from './routes/trophyRoutes';
import orderRoutes from './routes/orderRoutes';
import authRoutes from './routes/authRoutes';
import reportRoutes from './routes/reportRoutes';
import { authenticate } from './middlewares/authMiddleware';
import { errorHandler } from './middlewares/errorHandler';

dotenv.config();
connectDB();

const app = express();
app.use(express.json());

// Public Routes
app.use('/api/auth', authRoutes);

// Protected Routes (require authentication)
app.use(authenticate);
app.use('/api/trophies', trophyRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/reports', reportRoutes);

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

// Error Handling Middleware
app.use(errorHandler);

export default app;