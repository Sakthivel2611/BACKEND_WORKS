import Trophy from '../models/Trophy';

export const createTrophy = async (trophyData: any) => {
  const trophy = new Trophy(trophyData);
  return await trophy.save();
};

export const getTrophies = async () => {
  return await Trophy.find();
};

export const getTrophyById = async (id: string) => {
  return await Trophy.findById(id);
};

export const updateTrophy = async (id: string, updateData: any) => {
  return await Trophy.findByIdAndUpdate(id, updateData, { new: true });
};

export const deleteTrophy = async (id: string) => {
  return await Trophy.findByIdAndDelete(id);
};