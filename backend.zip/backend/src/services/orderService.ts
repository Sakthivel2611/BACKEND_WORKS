import Order from '../models/Order';

export const createOrder = async (orderData: any) => {
  const order = new Order(orderData);
  return await order.save();
};

export const getOrders = async () => {
  return await Order.find().populate('items.trophy');
};

export const getOrderById = async (id: string) => {
  return await Order.findById(id).populate('items.trophy');
};