import jwt from 'jsonwebtoken';

export const generateToken = (payload: string | object | Buffer): string => {
  const secret = process.env.JWT_SECRET;
  const expiration = process.env.JWT_EXPIRATION || '1h';

  if (!secret) {
    throw new Error('JWT_SECRET environment variable is not defined');
  }

  // Ensure the expiration is passed as part of the options object
  return jwt.sign(payload, secret as string, {
    expiresIn: expiration, // Valid property of jwt.SignOptions
  });
};