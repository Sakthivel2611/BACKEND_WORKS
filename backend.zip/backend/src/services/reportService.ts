import Order from '../models/Order';

export const calculateTotalSales = async (startDate: string, endDate: string) => {
  const orders = await Order.find({
    createdAt: { $gte: new Date(startDate), $lte: new Date(endDate) },
  });

  return orders.reduce((sum, order) => sum + order.total, 0);
};