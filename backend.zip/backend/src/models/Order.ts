import mongoose from 'mongoose';

const OrderSchema = new mongoose.Schema({
  customerName: { type: String, required: true },
  items: [
    {
      trophy: { type: mongoose.Schema.Types.ObjectId, ref: 'Trophy', required: true },
      quantity: { type: Number, required: true },
    },
  ],
  total: { type: Number, required: true },
  paymentMethod: { type: String, required: true },
  customNote: { type: String },
}, { timestamps: true });

export default mongoose.model('Order', OrderSchema);