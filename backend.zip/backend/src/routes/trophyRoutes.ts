import express from 'express';
import { getTrophies, createTrophy } from '../controllers/trophyController';

const router = express.Router();

router.get('/', getTrophies);
router.post('/', createTrophy);

export default router;